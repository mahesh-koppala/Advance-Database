
from flask import Flask, render_template, request, redirect, url_for
import os, shutil
import sqlite3

app = Flask(__name__)

print(os.getenv("PORT"))
port = int(os.getenv("PORT", 5000))

conn = sqlite3.connect('mahesh_123.db', check_same_thread=False)
print("Opened database successfully")
#cur = conn.cursor()


# default
@app.route('/', methods=["GET"])
def hello_world():
	return render_template('index.html', result={})


@app.route('/list_files', methods=["GET"])
def list_files():
	files_dict = {}
	files_list = os.listdir('./static/pics/')
	for file in files_list:
		file_name = './static/pics/' + file
		files_dict[file] = (os.stat(file_name).st_size, os.stat(file_name).st_mtime)
	return render_template('list_files.html', result=files_dict)


@app.route('/price_rng', methods=["GET"])
def search_room():
	ret = []
	return render_template('price_search.html', result=ret)


# search by name function
@app.route('/price_rng', methods=["POST"])
def search_by_room():
	price_st = request.form["price_start"]
	price_end = request.form["price_end"]
	if price_st == '' and price_end == '':
		price_st = 0
		price_end = 0
	if price_st == '':
		price_st = 0
	if price_end == '':
		price_end = 0
	cur = conn.cursor()
	cur.execute('SELECT * FROM food  WHERE Price between (?) and (?) ', (price_st, price_end, ))
	result = cur.fetchall()
	return render_template('price_search.html', result=result)


@app.route('/show_pic_by_name', methods=["GET"])
def show_pic():

	return render_template('show_pic.html', result={})


# search by name function
@app.route('/show_pic_by_name', methods=["POST"])
def show_pic_name():
	name_mem = request.form["name_mem"]
	cur = conn.cursor()
	cur.execute('SELECT * FROM food where Food = (?)', (name_mem,))
	result = cur.fetchall()
	print(result)
	return render_template('show_pic.html', result=result)

@app.route('/update_information', methods=["GET"])
def update_by_room():

	cur = conn.cursor()
	cur.execute('SELECT Food,Picture,Description FROM food where Food is Not Null')
	result = cur.fetchall()

	return render_template('update_information.html', result=result)



@app.route('/update_information', methods=["POST"])
def update_information():
	name = request.form.get('opt')
	
	description = request.form["description"]
	cur = conn.cursor()

	if description != '':
		cur.execute('UPDATE food SET Description = (?) WHERE Food = (?)', (description, name))
	conn.commit()
	return redirect(url_for("just_hello"))


@app.route('/list', methods=["GET"])
def just_hello():
	cur = conn.cursor()
	sql = "SELECT Food,Picture, Description FROM food where Food is Not Null;"
	cur.execute(sql)
	result = cur.fetchall()
	return render_template('update_information.html', result=result)

@app.route('/show_cont', methods=["GET"])
def show():
	file1 = open("text.txt", "r+")
	result = file1.readlines()
	print(result)
	return render_template('showcontents.html', result=result)


if __name__ == '__main__':
	app.run(host='0.0.0.0', port=port)

