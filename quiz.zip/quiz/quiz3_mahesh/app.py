
from flask import Flask, render_template, request, redirect, url_for
import os, json, datetime, random
import sqlite3
import math
from dbRedisCache import r
app = Flask(__name__)

print(os.getenv("PORT"))
port = int(os.getenv("PORT", 5000))

conn = sqlite3.connect('quake.db', check_same_thread=False)

print("Opened database successfully")



@app.route("/", methods=["GET"])
def hello():
   return render_template('mahesh_index.html')

@app.route('/summer_prob2', methods=["POST"])
def problem2a():
	start_elev = request.form["start_elev"]
	end_elev = request.form["end_elev"]
	
	start_time = datetime.datetime.now().timestamp()
	cursor = conn.cursor()
	sql = "SELECT latitude,longitude,place,mag,id from q where mag BETWEEN ? and ?"
	cursor.execute(sql, (end_elev,start_elev))

	result = cursor.fetchall()
	print(result)
	total_time = (datetime.datetime.now().timestamp() - start_time) * 1000
	return render_template('summer_prob2.html', execution_time= total_time, result=result)

@app.route('/prob9', methods=["POST"])
def prob9():
	start_elev = float(request.form["start_elev"])
	end_elev = float(request.form["end_elev"])
	number_d = float(request.form["number_d"])
	random_value=random.uniform(start_elev,end_elev)
	start_elev =random_value+number_d
	end_elev =random_value-number_d
	start_time = datetime.datetime.now().timestamp()
	cursor = conn.cursor()
	sql = "SELECT latitude,longitude,place,mag,id from q where mag BETWEEN ? and ?"
	cursor.execute(sql, (end_elev,start_elev))

	result = cursor.fetchall()
	print(result)
	total_time = (datetime.datetime.now().timestamp() - start_time) * 1000
	return render_template('prob9.html', execution_time= total_time, result=result)

	 
	 

@app.route('/prob123', methods=["POST"])
def prob123():
	query_count = int(request.form["query_count1"])
	start_elev = float(request.form["start_elev"])
	end_elev = float(request.form["end_elev"])
	number_d = float(request.form["number_d"])
	
	random_value=random.uniform(start_elev,end_elev)
	start_elev =random_value+number_d
	end_elev =random_value-number_d
	start_time = datetime.datetime.now().timestamp()
	cursor = conn.cursor()
	for _ in range(query_count):
		sql = "SELECT latitude,longitude,place,mag,id from q where mag BETWEEN ? and ?"
		cursor.execute(sql, (end_elev,start_elev))
		result = cursor.fetchall()
	print(result)
	total_time = (datetime.datetime.now().timestamp() - start_time) * 1000
	return render_template('prob123.html', execution_time= total_time, result=result)


@app.route('/probw', methods=["POST"])
def prob128():
	query_count = int(request.form["query_count1"])
	start_elev = float(request.form["start_elev"])
	end_elev = float(request.form["end_elev"])
	number_d = float(request.form["number_d"])
	
	random_value=random.uniform(start_elev,end_elev)
	start_elev =random_value+number_d
	end_elev =random_value-number_d
	start_time = datetime.datetime.now().timestamp()
	cursor = conn.cursor()
	cursor = conn.cursor()
	for _ in range(query_count):
		key = 'imq3_lat_' + str(end_elev) + str(start_elev)
		output = []
		if r.exists(key):
			output = json.loads(r.get(key))
		else:
			sql = "SELECT latitude,longitude,place,mag,id from q where mag BETWEEN ? and ?"
			cursor.execute(sql, (end_elev,start_elev))

			result = cursor.fetchall()
			r.set(key, json.dumps(output))
	print(result)
	total_time = (datetime.datetime.now().timestamp() - start_time) * 1000
	return render_template('probw.html', execution_time= total_time, result=result)




if __name__ == '__main__':
	app.run(host='0.0.0.0', port=port)





