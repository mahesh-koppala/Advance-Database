from flask import Flask, render_template, request, url_for
import os, json, datetime, random

import sqlite3
import math
#            ---------------------------           az webapp up --sku F1 -n mahesh6522-Quiz4
app = Flask(__name__)
port = int(os.getenv("PORT", 5000))

conn = sqlite3.connect('stat.db', check_same_thread=False)

print("Opened database successfully")

print("Opened database successfully")
@app.route("/", methods=["GET"])
def hello():
   return render_template('index.html')

@app.route('/prob6', methods=["POST"])
def problem_6():
	state_name = (request.form["state_name"]).capitalize()
	cursor = conn.cursor()
	sql = """ SELECT "2010","2011","2012","2013","2014","2015","2016","2017","2018" from s where State = (?) """
	
	cursor.execute(sql, (state_name,))
	result = cursor.fetchall()
	print(result)
	return render_template('prob6.html', result=result, size=len(result[0]))


@app.route('/prob7', methods=["POST"])
def scatter_p():
	li=[]
	state_name = (request.form["state_name"]).capitalize()
	state_nam = (request.form["state_nam"]).capitalize()
	state_na = (request.form["state_na"]).capitalize()
	sta = (request.form["sta"]).capitalize()
	li.append(state_name)
	li.append(state_nam)
	li.append(state_na)
	li.append(sta)
	print(li)
	year = (request.form["year"])
	cursor = conn.cursor()
	sql = """ SELECT "2010" from s where State = (?) or State=(?) or State = (?) or State = (?) """
	
	cursor.execute(sql, (state_name,state_nam,state_na,sta,))
	result = cursor.fetchall()
	print(result)
	return render_template('prob7.html', result=result, li=li)

@app.route('/prob8', methods=["POST"])
def scatter_pl():
	li=[]
	state_name = (request.form["state_name"]).capitalize()
	state_nam = (request.form["state_nam"]).capitalize()
	state_na = (request.form["state_na"]).capitalize()
	sta = (request.form["sta"]).capitalize()
	li.append(state_name)
	li.append(state_nam)
	li.append(state_na)
	li.append(sta)
	print(li)
	year = (request.form["year"])
	cursor = conn.cursor()
	sql = """ SELECT "2010" from s where State = (?) or State=(?) or State = (?) or State = (?) """
	
	cursor.execute(sql, (state_name,state_nam,state_na,sta,))
	result = cursor.fetchall()
	print(result)
	return render_template('pie_chart.html', result=result, li = li)

if __name__ == '__main__':
	app.run(host='0.0.0.0', port=port)



""" def get_mag_data():
	cursor = conn.cursor()
	sql = SELECT t.range as magnitudes, count(*) as occurance from (
		SELECT CASE WHEN mag >= 0 and mag < 1 THEN 0
		 WHEN mag >= 1 and mag < 2 THEN 1
		 WHEN mag >= 2 and mag < 3 THEN 2
		 WHEN mag >= 3 and mag < 4 THEN 3
		 WHEN mag >= 4 and mag < 5 THEN 4
		 WHEN mag >= 5 and mag < 6 THEN 5
		 WHEN mag >= 6 and mag < 7 THEN 6
		 WHEN mag >= 7 and mag < 8 THEN 7
		 WHEN mag >= 8 and mag < 9 THEN 8
		 WHEN mag >= 9 and mag < 10 THEN 9
		 ELSE -1 END as range from quakes) t group by t.range order by magnitudes
	cursor.execute(sql)
	return cursor.fetchall()

@app.route('/pie_chart', methods=["POST"])
def pie_chart():
	result = get_mag_data()
	return render_template('pie_chart.html', result=result)


@app.route('/bar_chart', methods=["POST"])
def bar_chart():
	result = get_mag_data()
	return render_template('new.html', result=result)


@app.route('/scatter_plot', methods=["POST"])
def scatter_plot():
	sql = "select latitude, longitude, mag from quakes"# where latitude between ? and ? and longitude between ? and ?;"
	cursor = conn.cursor()
	cursor.execute(sql)#, (latitude - step, latitude + step, longitude - step, longitude + step))
	result = cursor.fetchall()
	return render_template('scatter_plot.html', result=result, size=len(result))#, latitude_range=latitude_range, longitude_range =longitude_range)


@app.route('/line_chart', methods=["POST"])
def line_chart():
	sql = 'SELECT substr(time, 1, 10) as date, count(*) as occurences from quakes group by substr(time, 1, 10) order by date'
	cursor = conn.cursor()
	cursor.execute(sql)
	result1 = cursor.fetchall()
	print(result1)
	return render_template('line_chart.html', result=result1)
	
@app.route('/prob5v', methods=["POST"])
def prob5v():
	start_lat=(request.form['start_lat'])
	end_lat= (request.form['end_lat'])


	sql = SELECT t.range as magnitudes, count(*) as occurance from (
		SELECT CASE WHEN mag >= 0 and mag < 1 THEN 0
		 WHEN mag >= 1 and mag < 2 THEN 1
		 WHEN mag >= 2 and mag < 3 THEN 2
		 WHEN mag >= 3 and mag < 4 THEN 3
		 WHEN mag >= 4 and mag < 5 THEN 4
		 WHEN mag >= 5 and mag < 6 THEN 5
		 WHEN mag >= 6 and mag < 7 THEN 6
		 WHEN mag >= 7 and mag < 8 THEN 7
		 WHEN mag >= 8 and mag < 9 THEN 8
		 WHEN mag >= 9 and mag < 10 THEN 9
		 ELSE -1 END as range from quakes where latitude between (?) and (?)) t group by t.range order by magnitudes
	cursor = conn.cursor()
	cursor.execute(sql, (start_lat, end_lat))

	result = cursor.fetchall()
	
	return render_template('prob5v.html', result=result)

@app.route('/prob6v', methods=["POST"])
def prob6v():
	start_mag=(request.form['start_mag'])
	end_mag= (request.form['end_mag'])


	sql = SELECT t.range as magnitudes, count(*) as occurance from (
		SELECT CASE WHEN mag >= 0 and mag < 1 THEN 0
		 WHEN mag >= 1 and mag < 2 THEN 1
		 WHEN mag >= 2 and mag < 3 THEN 2
		 WHEN mag >= 3 and mag < 4 THEN 3
		 WHEN mag >= 4 and mag < 5 THEN 4
		 WHEN mag >= 5 and mag < 6 THEN 5
		 WHEN mag >= 6 and mag < 7 THEN 6
		 WHEN mag >= 7 and mag < 8 THEN 7
		 WHEN mag >= 8 and mag < 9 THEN 8
		 WHEN mag >= 9 and mag < 10 THEN 9
		 ELSE -1 END as range from quakes where mag between (?) and (?)) t group by t.range order by magnitudes
	cursor = conn.cursor()
	cursor.execute(sql, (start_mag, end_mag))

	result = cursor.fetchall()
	
	return render_template('line_chart.html', result=result)









@app.route('/prob9', methods=["POST"])
def problem_9():
	latitude1 = float (request.form["latitude1"])
	longitude1=float(request.form["longitude1"])
	distance1=float(request.form["distance1"])
	

	sql = SELECT t.range as magnitudes, count(*) as occurance from (
		SELECT CASE WHEN mag >= 0 and mag < 1 THEN 0
		 WHEN mag >= 1 and mag < 2 THEN 1
		 WHEN mag >= 2 and mag < 3 THEN 2
		 WHEN mag >= 3 and mag < 4 THEN 3
		 WHEN mag >= 4 and mag < 5 THEN 4
		 WHEN mag >= 5 and mag < 6 THEN 5
		 WHEN mag >= 6 and mag < 7 THEN 6
		 WHEN mag >= 7 and mag < 8 THEN 7
		 WHEN mag >= 8 and mag < 9 THEN 8
		 WHEN mag >= 9 and mag < 10 THEN 9
		 ELSE -1 END as range , latitude, longitude from quakes ) t group by t.range order by magnitudes
	cursor = conn.cursor()
	cursor.execute(sql)
	result = cursor.fetchall()
	i=0
	result1 = []
	for row in result:
		distancenew1 = round((((math.acos(math.sin((latitude1*(22/7)/180)) *
								math.sin((float(row[2])*(22/7)/180))+math.cos((latitude1*(22/7)/180)) *
								math.cos((float(row[2])*(22/7)/180)) *
								math.cos(((longitude1 - float(row[3]))*(22/7)/180))))*180/(22/7))*60*1.1515*1.609344),2)
		result[i] += (distancenew1,)
		if distancenew1 <= distance1:
			result1.append(result[i])
		i += 1
		

	return render_template('prob9.html', result=result1) """