Python version used: Python 3.8

import the csv file all_month.csv in your SqlLite for browser name the table as 'all_month'

To run locally, run the following commands:

pip install -r requirements
python hello.py