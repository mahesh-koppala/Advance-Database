
from flask import Flask, render_template, request, redirect, url_for
import os, datetime
import sqlite3
import math

app = Flask(__name__)

print(os.getenv("PORT"))
port = int(os.getenv("PORT", 5000))

conn = sqlite3.connect('quakes.db', check_same_thread=False)

print("Opened database successfully")

affc = 0
# default
# default
@app.route('/', methods=["GET"])
def hello_world():
	obj = {}

	return render_template('index.html', result=obj)

@app.route('/query1', methods=["POST"])
def query1():
	net = request.form["net"]
	cur = conn.cursor()
	cur.execute("""SELECT id, place, mag, REPLACE(REPLACE(time, 'Z', ' '), 'T', ' '), latitude, longitude, depth
	from quakes where net = ?""", (net,))
	result = cur.fetchall()
	return render_template('query1.html', len=len(result), result=result)

@app.route('/query8', methods=["POST"])
def query8():
	location = '%'+request.form["location"]+'%'
	magnst_one = request.form["magnst_one"]
	magnst_two = request.form["magnst_two"]
	cur = conn.cursor()
	
	if magnst_one > magnst_two:
		temp = magnst_one
		magnst_one = magnst_two
		magnst_two = temp
	cur = conn.cursor()
	cur.execute("""Select id, latitude, longitude,time, place  from quakes where place like ?  AND magNst BETWEEN (?) AND (?)""", (location,magnst_one,magnst_two))
	result = cur.fetchall()
	
	return render_template('query8.html', result=result)


@app.route('/query6', methods=["POST"])
def query5():
	beginning_latitude = float(request.form["beginning_latitude"])
	beginning_longitude = float(request.form["beginning_longitude"])

	ending_latitude = float(request.form["ending_latitude"])
	ending_longitude = float(request.form["ending_longitude"])


	if beginning_latitude > 90 or beginning_latitude < -90:
		return "beginning latitude is out of range"
	if ending_latitude > 90 or ending_latitude < -90:
		return "ending latitude is out of range"
	if beginning_longitude > 180 or beginning_longitude < -180:
		return "beginning longitude is out of range"
	if ending_longitude > 180 or ending_longitude < -180:
		return "ending longitude is out of range"

	if beginning_latitude < ending_latitude:
		return "starting latitude must be greater than the ending latitude"
	if beginning_longitude > ending_longitude:
		return "starting longitude must be greater than ending longitude"

	cur = conn.cursor()
	cur.execute("""select latitude, longitude, place from quakes where latitude between ? and ? and 
	longitude between ? and ?""", (ending_latitude, beginning_latitude, beginning_longitude, ending_longitude,))
	result = cur.fetchall()
	return render_template('query6.html', result=result)


@app.route('/query3', methods=["POST"])
def query3():
	location = float(request.form["location"])
	
	distance = float(request.form["distance"])
	cur = conn.cursor()
	cur.execute("""SELECT id, place, mag, time, latitude, longitude, depth from all_month""", ())
	result = cur.fetchall()
	i = 0
	result1 = []
	for row in result:
		distance1 = round((((math.acos(math.sin((latitude*(22/7)/180)) *
								math.sin((float(row[4])*(22/7)/180))+math.cos((latitude*(22/7)/180)) *
								math.cos((float(row[4])*(22/7)/180)) *
								math.cos(((latitude - float(row[5]))*(22/7)/180))))*180/(22/7))*60*1.1515*1.609344),2)
		result[i] += (distance1,)
		if distance1 <= distance:
			result1.append(result[i])
		i += 1
	return render_template('query3.html', result=result1)

	







   
   

if __name__ == '__main__':
	app.run(host='0.0.0.0', port=port)

