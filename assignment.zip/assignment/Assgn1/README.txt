Python version used: Python 3.7

To run locally, run the following commands

pip install -r requirements
python hello.py

To run on cloud,
Upload files and run the app