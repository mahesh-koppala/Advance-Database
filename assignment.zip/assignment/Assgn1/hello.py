"""Cloud Foundry test"""
from flask import Flask, render_template, request, redirect, url_for
import os
import sqlite3

app = Flask(__name__)

print(os.getenv("PORT"))
port = int(os.getenv("PORT", 5000))

conn = sqlite3.connect('people.db', check_same_thread=False)
print("Opened database successfully")


# default
@app.route('/', methods=["GET"])
def hello_world():
	return render_template('index.html', result={})


@app.route('/list_files', methods=["GET"])
def list_files():
	files_dict = {}
	files_list = os.listdir('./static/pics/')
	for file in files_list:
		file_name = './static/pics/' + file
		files_dict[file] = os.stat(file_name).st_size
	return render_template('list_files.html', result=files_dict)


@app.route('/search_sal', methods=["GET"])
def search_room():
	ret = []
	return render_template('salary_search.html', result=ret)


# search by name function
@app.route('/search_sal', methods=["POST"])
def search_by_room():
	sal_st = request.form["sal_start"]
	sal_end = request.form["sal_end"]
	if sal_st == '' and sal_end == '':
		sal_st = 0
		sal_end = 0
	if sal_st == '':
		sal_st = 0
	if sal_end == '':
		sal_end = 0
	cur = conn.cursor()
	cur.execute('SELECT * FROM people WHERE Salary between (?) and (?) ', (sal_st, sal_end, ))
	result = cur.fetchall()
	return render_template('salary_search.html', result=result)


@app.route('/show_pic_by_name', methods=["GET"])
def show_pic():
	ret = []
	return render_template('show_pic.html', result=ret)


# search by name function
@app.route('/show_pic_by_name', methods=["POST"])
def show_pic_name():
	name_mem = request.form["name_mem"]
	cur = conn.cursor()
	cur.execute('SELECT * FROM people where Name = (?)', (name_mem,))
	result = cur.fetchall()
	print(result)
	return render_template('show_pic.html', result=result)


@app.route('/update', methods=["GET"])
def update_by_room():
#	ret = []
	cur = conn.cursor()
	cur.execute('SELECT Name, Salary, Keywords FROM people where Name is Not Null')
	result = cur.fetchall()
#	for row in result:
#		ret.append(row[0])
#	print(ret)
	return render_template('update.html', result=result)


@app.route('/update', methods=["POST"])
def update():
	name = request.form.get('opt')
	salary = request.form["salary"]
	keywords = request.form["keywords"]
	cur = conn.cursor()
	if salary != '' and keywords != '':
		cur.execute('UPDATE people SET Keywords = (?), Salary = (?) WHERE Name = (?)', (keywords, salary, name))
	if salary != '':
		cur.execute('UPDATE people SET Salary = (?) WHERE Name = (?)', (salary, name))
	if keywords != '':
		cur.execute('UPDATE people SET Keywords = (?) WHERE Name = (?)', (keywords, name))
	conn.commit()
	return redirect(url_for("just_hello"))


@app.route('/list', methods=["GET"])
def just_hello():
	cur = conn.cursor()
	sql = "SELECT Name, Salary, Keywords FROM people where Name is Not Null;"
	cur.execute(sql)
	result = cur.fetchall()
	return render_template('update.html', result=result)


if __name__ == '__main__':
	app.run(host='0.0.0.0', port=port)

