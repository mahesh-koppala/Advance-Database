
from flask import Flask, render_template, request, redirect, url_for
import os, datetime
import sqlite3
import math

app = Flask(__name__)

print(os.getenv("PORT"))
port = int(os.getenv("PORT", 5000))

conn = sqlite3.connect('all_month.db', check_same_thread=False)

print("Opened database successfully")



@app.route('/', methods=["GET"])
def hello_world():
	obj = {}
	cur = conn.cursor()
	cur.execute("""SELECT MIN(REPLACE(REPLACE(time, 'Z', ''), 'T', ' ')) as startDate, 
					MAX(REPLACE(REPLACE(time, 'Z', ''), 'T', ' ')) as endDate FROM all_month""", ())
	result = cur.fetchone()

	obj["startdate"] = datetime.datetime.strptime(str(result[0]).strip().replace("()", ""),
												'%Y-%m-%d %H:%M:%S.%f').replace(hour=0,minute=0,second=0,microsecond=0)
	obj["enddate"] = datetime.datetime.strptime(str(result[1]).strip().replace("()", ""),
										'%Y-%m-%d %H:%M:%S.%f').replace(hour=23,minute=59,second=59,microsecond=999999)
	return render_template('index.html', result=obj)


# To get the total number of earthquakes by entering a magnitude
@app.route('/query1', methods=["POST"])
def query1():
	mag = request.form["mag"]
	cur = conn.cursor()
	cur.execute("""SELECT id, place, mag, REPLACE(REPLACE(time, 'Z', ' '), 'T', ' '), latitude, longitude, depth
	from all_month where mag >= ?""", (mag,))
	result = cur.fetchall()
	return render_template('query1.html', len=len(result), result=result)


# To get the details by entering the magnitude range and date range
@app.route('/query2', methods=["POST"])
def query2():
	starting_mag = request.form["starting_mag"]
	ending_mag = request.form["ending_mag"]
	if starting_mag > ending_mag:
		return "starting magnitude is more than the ending magnitude"
	cur = conn.cursor()
	if request.form["dates"] == "all":
		cur.execute("""SELECT * from all_month where mag between (?) and (?)""", (starting_mag, ending_mag,))
		result = cur.fetchall()
	elif request.form["dates"] == "date":
		beginning_range = datetime.datetime.strptime(request.form["beginning_range"], "%Y-%m-%d").replace(hour=0,
		minute=0, second=0, microsecond=0).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
		ending_range = datetime.datetime.strptime(request.form["ending_range"], "%Y-%m-%d").replace(hour=23,
		minute=59, second=59, microsecond=999999).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

		if beginning_range is None:
			return "Please enter the start date"
		if ending_range is None:
			return "Please enter the end date"
		if beginning_range > ending_range:
			return "start date greater than end date"
		cur.execute("""SELECT id, REPLACE(REPLACE(time, 'Z', ' '), 'T', ' '), mag, latitude, longitude, depth, place
		from all_month where mag between (?) and (?) and REPLACE(REPLACE(time, 'Z', ' '), 'T', ' ') 
		between (?) and (?)""", (starting_mag, ending_mag, beginning_range, ending_range,))
		result = cur.fetchall()
	else:
		result = []
	return render_template('query2.html', result=result)



@app.route('/magnitude_increment_point', methods=["POST"])
def magnitude_increment_point():
	starting_mag = float(request.form["starting_mag"])
	ending_mag = float(request.form["ending_mag"])
	if starting_mag > ending_mag:
		return "starting magnitude is more than the ending"
	cur = conn.cursor()
	ret = {}
	while starting_mag < ending_mag:
		cur.execute("""SELECT * from all_month where mag between (?) and (?)""", (starting_mag, starting_mag + 0.1))
		result = cur.fetchall()
		ret["Magnitude " + str(round(starting_mag, 1)) + " to " + str(round(starting_mag + 0.1, 1)) + ", " +
			str(len(result)) + " earthquakes"] = result
		starting_mag = starting_mag + 0.1
		starting_mag = round(starting_mag, 1)

	return render_template('magnitude_increment_point.html', result=ret)



@app.route('/query3', methods=["POST"])
def query3():
	latitude = float(request.form["latitude"])
	longitude = float(request.form["longitude"])
	distance = float(request.form["distance"])
	cur = conn.cursor()
	cur.execute("""SELECT id, place, mag, time, latitude, longitude, depth from all_month""", ())
	result = cur.fetchall()
	i = 0
	result1 = []
	for row in result:
		distance1 = round((((math.acos(math.sin((latitude*(22/7)/180)) *
								math.sin((float(row[4])*(22/7)/180))+math.cos((latitude*(22/7)/180)) *
								math.cos((float(row[4])*(22/7)/180)) *
								math.cos(((longitude - float(row[5]))*(22/7)/180))))*180/(22/7))*60*1.1515*1.609344),2)
		result[i] += (distance1,)
		if distance1 <= distance:
			result1.append(result[i])
		i += 1
	return render_template('query3.html', result=result1)


# find clusters of earth quake
@app.route('/query4', methods=["POST"])
def query4():
	beginning_latitude = float(request.form["beginning_latitude"])
	beginning_longitude = float(request.form["beginning_longitude"])

	ending_latitude = float(request.form["ending_latitude"])
	ending_longitude = float(request.form["ending_longitude"])

	step = float(request.form["step"])

	if beginning_latitude > 90 or beginning_latitude < -90:
		return "starting latitude is out of range"
	if ending_latitude > 90 or ending_latitude < -90:
		return "ending latitude is out of range"
	if beginning_longitude > 180 or beginning_longitude < -180:
		return "starting latitude is out of range"
	if ending_longitude > 180 or ending_longitude < -180:
		return "starting latitude is out of range"

	if beginning_latitude < ending_latitude:
		return "starting latitude must be more than the ending latitude"
	if beginning_longitude > ending_longitude:
		return "starting longitude must be more than the ending longitude"

	res = []
	maximum_quakes = 0
	maximum_latitude = 0
	maximum_longitude = 0

	latitude = beginning_latitude
	lats = []
	while latitude > ending_latitude:
		longitude = beginning_longitude
		longs = []
		while longitude < ending_longitude:
			cur = conn.cursor()
			cur.execute("""select count(*) from all_month 
			where latitude between ? and ? and 
			longitude between ? and ?""", (latitude - step, latitude, longitude, longitude + step,))
			cnt = int(cur.fetchone()[0])
			st = ''
			st = st + str(latitude) + 'N ' + str(longitude) + 'W: '
			st = st + str(cnt)
			
			longs.append(cnt)
			longitude = longitude + step

			if cnt > maximum_quakes:
				maximum_quakes = cnt
				maximum_latitude = latitude
				maximum_longitude = longitude

		lats.append(longs)
		latitude = latitude - step
	res.append(lats)

	ret = {}
	ret["latitude"] = beginning_latitude
	ret["longitude"] = beginning_longitude
	ret["data"] = res[0]
	ret["maximum_quakes"] = maximum_quakes
	ret["maximum_latitude"] = maximum_latitude
	ret["maximum_longitude"] = maximum_longitude
	ret["step"] = step
	return render_template('query4.html', result=ret)


# get the details such as latitude, longitude, and place  for all the  earthquakes within the given latitude and longitude range
@app.route('/query5', methods=["POST"])
def query5():
	beginning_latitude = float(request.form["beginning_latitude"])
	beginning_longitude = float(request.form["beginning_longitude"])

	ending_latitude = float(request.form["ending_latitude"])
	ending_longitude = float(request.form["ending_longitude"])


	if beginning_latitude > 90 or beginning_latitude < -90:
		return "beginning latitude is out of range"
	if ending_latitude > 90 or ending_latitude < -90:
		return "ending latitude is out of range"
	if beginning_longitude > 180 or beginning_longitude < -180:
		return "beginning longitude is out of range"
	if ending_longitude > 180 or ending_longitude < -180:
		return "ending longitude is out of range"

	if beginning_latitude < ending_latitude:
		return "starting latitude must be greater than the ending latitude"
	if beginning_longitude > ending_longitude:
		return "starting longitude must be greater than ending longitude"

	cur = conn.cursor()
	cur.execute("""select latitude, longitude, place from all_month where latitude between ? and ? and 
	longitude between ? and ?""", (ending_latitude, beginning_latitude, beginning_longitude, ending_longitude,))
	result = cur.fetchall()
	return render_template('query5.html', result=result)


# Delete the specific earth quake by providing the date occured and the magnitude range
@app.route('/query6', methods=["POST"])
def query6():
	beginning_magnitude = request.form["beginning_magnitude"]
	ending_magnitude = request.form["ending_magnitude"]

	if beginning_magnitude > ending_magnitude:
		return "starting magnitude is higher than ending magnitude"
	date = request.form["start_date"]
	cur = conn.cursor()
	cur.execute("""Select count(*) from all_month""", ())
	previous_count = int(cur.fetchone()[0])
	cur.execute("""Delete from all_month 
	where date(REPLACE(REPLACE(TIME, 'Z', ' '), 'T', ' ')) = ? 
	and mag between ? and ?""", (date, beginning_magnitude, ending_magnitude,))
	conn.commit()
	rdel = cur.rowcount
	after_count = previous_count - rdel
	ret = "records deleted: " + str(rdel) + ", records remaining: " + str(after_count)

	return render_template('query6.html', result=ret)


if __name__ == '__main__':
	app.run(host='0.0.0.0', port=port)

